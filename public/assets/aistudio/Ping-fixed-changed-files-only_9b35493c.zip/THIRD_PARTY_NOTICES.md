# Third-party notices

## Spam detection data

Ping's on-device spam model is trained at build time from the **Indian Telecom SMS Spam Collection**
by junioralive: https://github.com/junioralive/india-spam-sms-classification
(dataset file `dataset/spam_ham_india.csv`; see the repository's LICENSE file for its terms).

Only word statistics derived from the dataset ship inside the app (`public/spam-model.json`); the raw messages
are not included. The model is combined with a small hand-written seed set (`scripts/spam-seed.csv`) and a list
of scam patterns (`scripts/spam-rules.mjs`).
