import { tokenize } from './tokenize.js';

/**
 * Turns the raw JSON model into one with its regular expressions compiled.
 * @param {any} raw
 */
export function compileModel(raw) {
  const compile = (list) =>
    (list || []).map((r) => ({ re: new RegExp(r.re, 'i'), w: Number(r.w) || 0, strong: !!r.strong }));
  return {
    version: raw.version,
    bias: Number(raw.bias) || 0,
    weights: raw.weights || {},
    rules: compile(raw.rules),
    safe: (raw.safe || []).map((s) => new RegExp(s, 'i')),
  };
}

/**
 * Scores one message. `p` is the spam probability from the language model plus scam rules;
 * `safe` means it looks like an OTP, bank alert or delivery update and must never be filtered.
 * @param {ReturnType<typeof compileModel>} model
 * @param {string} text
 * @returns {{ p: number, logOdds: number, safe: boolean, strong: boolean }}
 */
export function scoreMessage(model, text) {
  const body = String(text || '');
  let logOdds = model.bias;
  for (const tok of tokenize(body)) {
    const w = model.weights[tok];
    if (w !== undefined) logOdds += w;
  }
  let strong = false;
  for (const rule of model.rules) {
    if (rule.re.test(body)) {
      logOdds += rule.w;
      if (rule.strong) strong = true;
    }
  }
  const safe = !strong && model.safe.some((re) => re.test(body));
  const clamped = Math.max(-30, Math.min(30, logOdds));
  return { p: 1 / (1 + Math.exp(-clamped)), logOdds, safe, strong };
}

/** Same thresholds the Settings screen offers. */
export const SPAM_THRESHOLDS = { relaxed: 0.95, balanced: 0.85, strict: 0.65 };

/** Senders registered with Indian telecom regulation look like "AX-EPFOHO-S" or "JD-AXISBK-S". */
const REGISTERED_SENDER_RE = /^[a-z]{2}-[a-z0-9]{3,10}(?:-[a-z])?$/i;

/**
 * Final yes/no. Rules:
 *  - OTP / bank / delivery style messages are never spam.
 *  - Messages from registered sender IDs are ordinary marketing (they belong in Promotions) and are
 *    only treated as spam when they also trip a strong scam pattern (KYC threat, lottery, ...).
 *  - Everything else (phone numbers, unknown senders) is spam when its score reaches the threshold.
 * @param {{ p: number, safe: boolean, strong: boolean }} result
 * @param {string} sender
 * @param {number} threshold
 */
export function isSpamResult(result, sender, threshold) {
  if (result.safe) return false;
  if (REGISTERED_SENDER_RE.test(String(sender || '').trim()) && !result.strong) return false;
  return result.p >= threshold;
}
