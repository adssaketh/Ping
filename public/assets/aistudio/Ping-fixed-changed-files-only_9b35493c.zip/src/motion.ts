import { useEffect, useState } from 'react';

/**
 * Shared motion language (Material 3 Expressive): springs with a little overshoot for things that
 * move, short emphasized-easing fades for things that appear in place.
 */
export const spring = { type: 'spring', stiffness: 420, damping: 36, mass: 0.9 } as const;
export const springBouncy = { type: 'spring', stiffness: 520, damping: 26, mass: 0.85 } as const;
export const springSoft = { type: 'spring', stiffness: 300, damping: 34, mass: 1 } as const;

const emphasized: [number, number, number, number] = [0.2, 0, 0, 1];
export const fadeFast = { duration: 0.18, ease: emphasized };

/** True on tablet / desktop widths where Ping shows list and chat side by side. */
export function useIsDesktop(): boolean {
  const query = '(min-width: 768px)';
  const [matches, setMatches] = useState<boolean>(
    () => typeof window !== 'undefined' && window.matchMedia(query).matches
  );
  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setMatches(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);
  return matches;
}
